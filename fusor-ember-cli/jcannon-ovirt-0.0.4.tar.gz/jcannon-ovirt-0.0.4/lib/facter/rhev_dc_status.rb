Facter.add(:rhev_dc_status) do
   setcode 'rhevm-shell -E "show datacenter Default" | grep status-state | awk \'{print $3;}\' '
end
