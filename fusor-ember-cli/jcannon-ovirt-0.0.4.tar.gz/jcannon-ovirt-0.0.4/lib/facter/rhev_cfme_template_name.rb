Facter.add(:rhev_cfme_template_name) do
   setcode 'rhevm-shell -E "list templates --storagedomain-identifier my_export" | grep -B 1 "Red Hat CloudForms" | head -n1 | awk \'{print $3;}\' '
end

